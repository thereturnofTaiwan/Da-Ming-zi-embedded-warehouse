The following trace tools are supported:

#####################################################################################
SEGGER SystemView for uC/OS-III

Download the embedded target code to support Segger's SystemView for uC/OS-III 
from the following website https://www.segger.com/downloads/free_tools#SystemView 
and place the files in this folder.
#####################################################################################